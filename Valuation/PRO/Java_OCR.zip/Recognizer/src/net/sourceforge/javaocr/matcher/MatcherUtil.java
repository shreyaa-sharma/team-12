/*
 * Copyright (c) 2003-2012, Ronald B. Cemer , Konstantin Pribluda, William Whitney, Andrea De Pasquale
 *
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.sourceforge.javaocr.matcher;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * useful utility methods
 *
 * @author Konstantin Pribluda
 */
public class MatcherUtil {
    /**
     * extract candidates with matches in required list. Useful to increase match
     * quality (use free space matches as required)
     *
     * @param candidates candidates to check
     * @param required   only those matches are passed through
     * @return combined list of matches
     */
    public static List<Match> merge(List<Match> candidates, List<Match> required) {
        ArrayList<Match> retval = new ArrayList();
        Set<Character> contained = new HashSet();
        for (Match match : required) {
            contained.add(match.getChr());
        }
        for (Match match : candidates) {
            if (contained.contains(match.getChr()))
                retval.add(match);
        }
        return retval;
    }
}
